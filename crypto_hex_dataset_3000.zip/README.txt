Synthetic crypto-labeled hex dataset (3000 samples)

Each .hex file contains space-separated byte tokens (00–ff) representing a binary-like blob.
Labels include architecture, crypto primitives, and protocols in metadata files.
Markers are injected near the start to help parsers.

Files:
- hex_samples/*.hex
- metadata.csv
- metadata.jsonl
